<?php
 
class DbOperation
{
    private $con;

    function __construct()
    {
        require_once dirname(__FILE__) . '/DbConnect.php';
        $db = new DbConnect();
        $this->con = $db->connect();
    }
	
	function checkUser($un,$psw){
		$stmt = $this->con->prepare("SELECT username,password FROM utente WHERE username = ? and password = ?");
        $stmt->bind_param("ss", $un, $psw);
        $stmt->execute();
        $stmt->store_result();
        
        if($stmt->num_rows > 0)
            return true;
        else
            return false;
	}
}