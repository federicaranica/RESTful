package com.example.federica.log_in;

public class Api {
    private static final String ROOT_URL = "http://192.168.1.11/API_login/api/api.php?apicall=";

    public static final String URL_CHECK_USER = ROOT_URL + "checkUser";
}
