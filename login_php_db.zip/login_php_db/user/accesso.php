<?php
    $n = $_POST["nu"];
    $p = $_POST["pwd"];

    // include database and object files
    include_once '../config/database.php';
    include_once '../objects/user.php';
    
    // get database connection
    $database = new Database();
    $db = $database->getConnection();
    
    // prepare user object
    $user = new User($db);
    // set ID property of user to be edited
    $user->nome_utente = isset($_POST['nu']) ? $n : die();
    $user->password = isset($_POST['pwd']) ? $p : die();
    // read the details of user to be edited
    $stmt = $user->login();
    if($stmt->rowCount() > 0){
        //output
        echo "<center>";
        echo "<h1 style=\"color:red\">BENVENUTO " . $n . "!</h1><br><br>";
        echo "<br>";
        echo "<a href=\"./log_in.html\"><button>LOG OUT</button></a>"; 
        echo "</center>";
    }
    else{
        echo "<center><h1 style=\"color:red\"> UTENTE NON REGISTRATO!</h1></center>";
        echo "<a href=\"./sign_up.html\"><button>LOG OUT</button></a><br><br>"; 
        echo "<a href=\"./sign_up.html\"><button>REGISTRATI</button></a><br><br>"; 
        echo "</center>";
    }
?>