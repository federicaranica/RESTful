<?php
    $n = $_POST["nu"];
    $p = $_POST["pwd"];

    // include database and object files
    include_once '../config/database.php';
    include_once '../objects/user.php';
    
    // get database connection
    $database = new Database();
    $db = $database->getConnection();
    
    // prepare user object
    $user = new User($db);
    // set ID property of user to be edited
    $user->nome_utente = isset($_POST['nu']) ? $n : die();
    $user->password = isset($_POST['pwd']) ? $p : die();
    // read the details of user to be edited
    $stmt = $user->signup();
    //output
    if($stmt)
    {
        echo "<center>";
        echo "<h1 style=\"color:red\">Registrazione avvenuta con successo!</h1><br><br>";
        echo "<br>";
        echo "<a href=\"./log_in.html\"><button>INDIETRO</button></a>"; 
        echo "</center>";
    }
    else
    {
        echo "<center>";
        echo "<h1 style=\"color:red\">Errore!</h1><br><br>";
        echo "<br>";
        echo "<a href=\"./log_in.html\"><button>INDIETRO</button></a>"; 
        echo "</center>";
    }
?>