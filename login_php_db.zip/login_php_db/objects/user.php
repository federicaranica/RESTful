<?php
class User{
 
    // database connection and table name
    private $conn;
    private $table_name = "utente";
 
    // object properties
    public $nome_utente;
    public $password;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
    // login user
    function login(){
        // select all query
        $query = "SELECT
                    `nome_utente`, `password`
                FROM
                    " . $this->table_name . " 
                WHERE
                    nome_utente='".$this->nome_utente."' AND password='".$this->password."'";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        // execute query
        $stmt->execute();
        return $stmt;
    }

    function signup() {
        $query = "INSERT INTO " . $this->table_name . " (nome_utente,password) 
                    VALUES (\"" . $this->nome_utente . "\",\"" . $this->password . "\")";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        // execute query
        if($stmt->execute())
            return true;
        else
            return false;
        
    }
}


